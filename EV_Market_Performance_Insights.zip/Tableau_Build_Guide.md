# Tableau Build Guide

## System requirements from the assignment

- **Processor:** dual-core Intel i3 or equivalent; Intel i5 / Ryzen 5 or higher recommended.
- **Memory:** 8 GB minimum; 16 GB recommended for large datasets.
- **Storage:** 2–3 GB free minimum; SSD with 10+ GB free recommended.
- **Operating system:** Windows 10/11 (64-bit) or a supported current macOS version.
- **Software:** Tableau Desktop or Tableau Public.
- **Browser:** current Chrome, Edge, or Safari.
- **Data source:** Excel, CSV, or a database such as SQL; this project uses CSV.
- **Internet:** stable connection for Tableau Server / Tableau Cloud publishing.

## Connect and name

1. To use the finished workbook, open `EV_Market_Performance_Insights_Complete.twbx` in Tableau Public or Tableau Desktop. Its extract is packaged, so you do not need to reconnect the CSV.
2. The workbook contains the **EV Market Overview** dashboard and eight worksheets: **Manufacturer Sales**, **Sales by Category**, **Sales by Model Year**, **Sales by Manufacturing Country**, **Battery Type Sales Mix**, **Average Rating by Category**, **Average Range by Battery**, and **Average Capacity by Battery**. The dashboard places the three core sales views; open the remaining worksheet tabs for the supporting comparisons.
3. To build from the raw data instead, choose **Connect → To a File → Text file**, then open `ev_market_test.csv`. Confirm one table with 100,000 rows and 37 columns. Keep the data at vehicle-record grain; do not join or blend it.
4. Save any edited copy as a Tableau packaged workbook (`.twbx`) to keep its data extract with the workbook. Use the warning text **Illustrative analysis of supplied test data — not verified market reporting.** when adding context to the dashboard.

## Technical architecture

```text
CSV source → Tableau data connection → prepared worksheets → interactive dashboard → Tableau Public/Cloud share link
```

For the included browser dashboard, the CSV is read from the same folder via a loopback-only Python HTTP server; calculations and charts run in the browser. No remote service is used by that local dashboard.

## Dashboard layout

- KPI tiles: distinct manufacturer labels (`COUNTD(Manufacturer)`), distinct model names (`COUNTD(Model Name)`), reported annual sales (`SUM(Annual Sales Units)`), average customer rating (`AVG(Customer Rating)`), average driving range (`AVG(Range Km)`), and average battery capacity (`AVG(Battery Capacity Kwh)`). Label sales as reported in the dataset.
- Reported sales by **Model Year** (cohort comparison; do not label as calendar-year market growth).
- Center: top 10 manufacturers by reported sales (horizontal bars).
- Sales by category and records by manufacturing country. Country counts describe records, not production volume. Market Region can be added as a filter or secondary breakdown.
- Battery type comparison (average range and average capacity); a separate record-count view can show battery-type mix.
- Bottom center: range vs. battery capacity scatter, color by battery type, detail by vehicle ID, trend line optional.
- Bottom right: average customer rating by vehicle category.
- Filters: Model Year, Market Region, Category, Battery Type; apply to all relevant worksheets. Add Manufacturer as an optional filter.

## Calculations

```text
Manufacturer Labels = COUNTD([Manufacturer])\nEV Models = COUNTD([Model Name])\nVehicle Records = COUNTD([Vehicle Id])\nAverage Battery Capacity = AVG([Battery Capacity Kwh])
Reported Sales Units = SUM([Annual Sales Units])
Dataset Sales Mix = SUM([Annual Sales Units]) / TOTAL(SUM([Annual Sales Units]))
Average Rating = AVG([Customer Rating])
```

Use `Dataset Sales Mix` as a table calculation within the selected dimension and clearly label it as the mix of values in this file. The packaged workbook uses AVG aggregation on its rating, range, and capacity comparison worksheets. Null values should remain null; do not replace missing ratings/sales with zero.

## Data-quality and interpretation note

The CSV is called `ev_market_test.csv`, contains 100,000 rows and 200 manufacturer labels, has nearly even country and region distributions, and does not include source citations. Treat it as simulated/test data until provenance is established. Aggregated sales are illustrative and cannot substantiate real sales growth, manufacturer market share, or customer sentiment. `Model Year` describes the vehicle record, not the year in which sales transactions occurred.

## Walkthrough

1. Start with the four KPI tiles and explain their selected filters.
2. Compare model-year cohorts and category sales mix within the file.
3. Compare battery chemistry, capacity, and range.
4. Close with rating differences and the source-data limitations.

