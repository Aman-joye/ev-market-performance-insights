@echo off
cd /d "%~dp0"
start "EV Dashboard" http://127.0.0.1:8765/dashboard.html
python -m http.server 8765 --bind 127.0.0.1
