# Electric Vehicle Market Performance & Insights

## Project brief

Create an interactive analysis of the supplied EV test dataset, focusing on reported sales, vehicle segments, battery technology, range, customer ratings, and manufacturers. The intended deliverable is a Tableau-ready analysis project with a working browser dashboard, documented data, and a reproducible Tableau build path.

## Intended audiences

- **Emily Johnson — EV Market Strategy Director:** compare category performance and vehicle attributes to inform portfolio planning.
- **David Chen — Automotive Business Intelligence Manager:** explore manufacturer and regional patterns in the supplied data.
- **Dr. Sarah Williams — Sustainable Mobility Research Analyst:** compare battery types, range, efficiency, and the source's estimated CO₂ measure.

These names and scenarios are assignment personas, not real stakeholders or endorsements.

## Epics and 14 tasks

1. **Scope & success criteria**
   - Define audience questions, measures, and intended dashboard decisions.
   - Record acceptance criteria and limits on interpretation.
2. **Data intake & profiling**
   - Load the supplied CSV and confirm its 100,000-row, 37-field record structure.
   - Profile field types, distinct values, ranges, and missing values.
3. **Data preparation**
   - Assign readable Tableau names and types while preserving source values and nulls.
   - Define reported-sales, record-count, average, and dataset-mix calculations.
4. **Market overview**
   - Create KPI and model-year cohort views.
   - Compare category and region totals with dataset-only labels.
5. **Vehicle & battery analysis**
   - Compare range and capacity across battery technologies.
   - Explore capacity, range, efficiency, and estimated emissions at record level.
6. **Customer & manufacturer analysis**
   - Compare source ratings by category and manufacturer sales totals.
7. **Dashboard integration**
   - Assemble views and apply year, region, category, battery, and manufacturer filters.
   - Add definitions, source note, and test-data limitation.
8. **Review & handoff**
   - Review null handling, labels, filter behavior, and export legibility.
   - Package the browser dashboard, source data, dictionary, and Tableau instructions.

## Acceptance criteria

- Covers sales, category, region, battery/range, ratings, and manufacturer views.
- Filters update all dashboard metrics and charts.
- Missing measurements are excluded from the corresponding aggregate, not converted to zero.
- Model year is described as a vehicle cohort, not a sales transaction timeline.
- Dataset totals are never presented as verified market share, market growth, or customer sentiment.
- Tableau users can recreate the analysis from the included CSV and build guide.

## Technical architecture

```text
ev_market_test.csv ──┬──> Tableau Public/Desktop ──> Rebuilt workbook (.twbx)
                     │
                     └──> Local Python HTTP server ──> dashboard.html
                                                    └──> browser-side filters, aggregation, SVG charts
```

The HTML dashboard reads the adjacent CSV in the browser. The included Windows launcher starts a loopback-only Python static file server; no data is uploaded. `EV_Market_Performance_Insights_Complete.twbx` is a local Tableau packaged workbook containing the dataset extract, the EV Market Overview dashboard, and three worksheets. The Tableau build guide documents its current views and explains how to extend the workbook. No hosted demo or public Tableau/GitHub link is included; publishing requires the user's account and explicit publication choice.

## Source file and deliverables

The project copy of `ev_market_test.csv` is byte-for-byte identical to the supplied file at `C:\Users\Amanj\Downloads\ev_market_test.csv` (SHA-256: `28DE86CBDA822CBFCBADE9778DC952BAFAF0574F74FDC7372315D187A2148EEF`). The packaged workbook and browser dashboard use this supplied EV dataset. See `README.md` for the file inventory and data interpretation notes.
