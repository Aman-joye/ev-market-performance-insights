# EV Market Performance & Insights — Story Scenes

This storyboard adapts the project scenes shown in the SkillWallet screenshots to the supplied `ev_market_test.csv`. The screenshots also contain sample descriptions for online learning and heart disease; those are template examples and do not describe this EV project.

## Scene 1 — The EV dataset at a glance

**Question:** What is in the file, and what can this analysis support?

Introduce the 100,000 vehicle records, 37 columns, 200 manufacturer labels, and the measures available: reported annual sales, vehicle category, model year, battery type, driving range, capacity, and customer rating. State up front that this is a test file without source citations. Its results describe the supplied data only.

**Visuals:** KPI cards for distinct vehicle records, reported annual sales units, average range, and average rating. Use shared filters for model year, market region, category, battery type, and manufacturer.

## Scene 2 — Category performance and distribution

**Question:** Which vehicle categories account for the most reported units in this file?

Compare categories using summed nonblank `Annual Sales Units`. Use a sorted bar chart and a category filter. Describe the result as a dataset ranking, not verified market demand.

## Scene 3 — Manufacturer comparison

**Question:** How are reported units distributed among manufacturer labels?

Rank manufacturers by summed nonblank annual sales units, with a Top 10 view and manufacturer filter. Manufacturer labels look synthetic and lack provenance, so do not infer real-world leadership or market share.

## Scene 4 — Ratings by vehicle category

**Question:** How do the recorded customer ratings vary across categories?

Compare average nonblank `Customer Rating` by category. Show the scale as 1–5 and the record count in tooltips where possible. Ratings are values in the file, not independently validated customer sentiment.

## Scene 5 — Model-year cohorts

**Question:** How do reported units vary among vehicle model years?

Plot summed nonblank annual sales units by `Model Year`. Call this a model-year cohort comparison: the dataset does not provide a transaction date, so it cannot establish calendar-year sales growth.

## Scene 6 — Battery technology and vehicle capability

**Question:** How do battery types compare on range and capacity?

Compare mean range and mean capacity by battery type, then explore the capacity-versus-range scatter plot. If showing a battery-type proportion, label it **record mix in this file**, not market share. Keep missing values excluded from the relevant averages.

## Scene 7 — Manufacturing footprint and recommendations

**Question:** Where are manufacturing records assigned, and what should a decision-maker take away?

Show the manufacturing-country/market-region distribution available in the file. Discuss the pattern as a distribution of records, not verified production volume. Close with a practical recommendation: use the dashboard to explore segment and specification patterns, then obtain a provenance-verified source before making investment, policy, or market-sizing decisions.

## Suggested 5–7 minute walkthrough

1. **0:00–0:40 — Introduction:** project title, analyst/team name, and the decision questions.
2. **0:40–1:20 — Dataset and preparation:** CSV connection, 100,000 × 37 structure, null handling, and test-data caveat.
3. **1:20–2:00 — Overview:** KPI cards and shared filters.
4. **2:00–2:50 — Segment and manufacturer scenes:** compare category and manufacturer rankings.
5. **2:50–3:35 — Customer ratings:** explain scale and missing-value handling.
6. **3:35–4:20 — Model-year cohorts:** clarify model year versus transaction year.
7. **4:20–5:10 — Battery capability:** compare chemistry, range, and capacity.
8. **5:10–5:50 — Geography and conclusion:** describe distribution cautiously and state the next data-validation step.
9. **5:50–6:30 — Optional Q&A/limitations:** demonstrate one filter interaction and recap what the file cannot prove.

## Deliverable status

- Local browser dashboard: all seven analytical themes are represented across its KPI and chart panels; filters update the views.
- Packaged Tableau workbook: includes the overview dashboard and eight worksheets, including country, battery sales mix, rating, range, and capacity comparisons. The dashboard currently places the three core sales views; the supporting analyses are available as individual worksheets.
- Recording, Tableau Public publishing, Flask hosting, and SkillWallet demo/GitHub links: these require a human voice/account or an external publishing action and are not fabricated in this local project package.
