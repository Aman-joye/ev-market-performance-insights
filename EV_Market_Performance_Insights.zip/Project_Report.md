# Electric Vehicle Market Performance and Insights

## Project report and reproducible handoff

Prepared from the user-supplied `ev_market_test.csv` on 2 November 2026.

This project turns the supplied EV test file into a filterable dashboard and Tableau workbook for exploring vehicle segments, reported sales, manufacturer labels, battery specifications, model-year cohorts, ratings, and manufacturing geography. The dataset has no cited provenance, so all results describe this file only and should not be presented as verified market facts.

## Project questions and intended audience

The assignment describes three audience scenarios: an EV strategy director comparing categories, an automotive business intelligence manager comparing manufacturer and regional patterns, and a sustainable mobility researcher examining battery and vehicle attributes. These are project personas, not actual sponsors.

- Which categories and manufacturer labels have the highest reported annual-sales totals in this file?
- How do source ratings, range, capacity, and battery types vary across records?
- How are records distributed across model-year cohorts, market regions, and manufacturing countries?

## Dataset and preparation

The CSV contains 100,000 rows and 37 columns at vehicle-record grain. It includes vehicle identifiers and model names, manufacturers, model years, categories, battery specifications, driving range, annual sales units, customer ratings, manufacturing countries, and market regions.

| Profile item | Observed value |
| --- | --- |
| Coverage fields | Model years 2018–2026; 200 manufacturer labels; 15 categories; 7 market-region labels; 10 manufacturing-country labels |
| Missing data | 9,511 blanks across five fields |
| Missing values by field | Resale value 3,057; battery cycle life 2,028; customer rating 1,931; infotainment screen 1,506; annual sales units 989 |
| Aggregate checks | Reported annual sales 772,608,124 nonblank units; mean range 324.3 km; mean rating 4.08/5 |

The project keeps the original record grain and preserves nulls. Each metric excludes blanks in its own field; missing ratings and sales are not treated as zero. `Model Year` describes a vehicle cohort, not a sales transaction date.

## Dashboard design

The browser dashboard follows the supplied overview reference with six KPI cards and linked analytical views. Model year, market region, category, battery type, and manufacturer text filters recalculate all KPI cards and charts together.

| View | Reading the result |
| --- | --- |
| KPI cards | Distinct manufacturers and model names, reported annual sales, average source rating, average range, and average battery capacity after filters |
| Reported sales by model year | Compare reported units across model-year cohorts; this is not calendar-year growth |
| Top manufacturers by reported sales | Rank manufacturer labels within this file; not a verified real-world ranking |
| Reported sales by category | Compare category totals within the supplied file |
| Records by manufacturing country | Count vehicle records by country; this does not establish production volume |
| Battery technology comparison | Compare mean range and battery capacity for battery types |
| Capacity and range scatter | Sampled vehicle records show the relationship between capacity and range |
| Rating by category | Compare average nonblank source ratings on the file’s 1–5 scale |

## Findings and limits

Across all rows, the file sums to 772,608,124 nonblank reported annual-sales units. Mean driving range is 324.3 km, and mean customer rating is 4.08 on the source’s 1–5 scale. These are descriptive summaries of the CSV, not validated market estimates.

The filename identifies the data as a test file, manufacturer labels appear synthetic, country and region distributions look unusually balanced, and the file has no source or collection-method citations. Do not use the results to claim market share, actual sales growth, verified customer sentiment, production output, or causal effects. A cited, validated source is needed before investment, policy, or market-sizing decisions.

## Technical architecture and run instructions

The local dashboard runs as a static HTML page served by a loopback-only Python HTTP server. The browser reads the adjacent CSV and calculates filtered summaries locally. The Tableau packaged workbook contains its data extract and opens without reconnecting the CSV.

1. Keep `dashboard.html`, `ev_market_test.csv`, and `Start_Dashboard.bat` in the same folder.
2. On Windows with Python 3 installed, double-click `Start_Dashboard.bat`. It opens the local dashboard at `http://127.0.0.1:8765`. Keep the command window open while using it; close it to stop the server.
3. Open `EV_Market_Performance_Insights_Complete.twbx` in Tableau Public or Tableau Desktop. It includes an extract, an overview dashboard, and eight worksheets: Manufacturer Sales, Sales by Category, Sales by Model Year, Sales by Manufacturing Country, Battery Type Sales Mix, Average Rating by Category, Average Range by Battery, and Average Capacity by Battery. The dashboard currently places the three core sales views; the remaining views are available as individual worksheets.
4. Use `Tableau_Build_Guide.md` for field calculations, interpretation, and extension steps. Save edited work as a packaged `.twbx` to keep the extract with the workbook.

## Story and walkthrough

`Scene_Storyboard.md` provides a seven-scene narrative and a timed 5–7 minute walkthrough covering dataset scope, category comparison, manufacturer ranking, ratings, model-year cohorts, battery capability, and manufacturing footprint. The closing should state the data limits and identify the next validation step.

## Files in this package

- `dashboard.html` — interactive browser dashboard with shared filters.
- `EV_Market_Performance_Insights_Complete.twbx` — packaged Tableau workbook and extract.
- `EV_Market_Performance_Insights_Complete.twb` — editable workbook definition.
- `ev_market_test.csv` — supplied dataset copy.
- `Data_Dictionary.csv` — field descriptions, types, units, and missing counts.
- `Project_Plan.md` — eight epics, fourteen tasks, acceptance criteria, and architecture.
- `Scene_Storyboard.md` — seven scenes and presentation outline.
- `Tableau_Build_Guide.md` — workbook contents, calculations, caveats, and extension steps.
- `Start_Dashboard.bat` — local Windows launcher.

## External handoff status

The local assets are prepared. This package does not claim Tableau Public publishing, a hosted demo or Flask integration, a video recording, or SkillWallet links have been completed. Publishing requires the owner’s account and an external action; the 5–7 minute outline is included to support the owner’s recording.
